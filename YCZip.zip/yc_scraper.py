"""
YC STARTUP INTELLIGENCE — Step 1: Data Collection
===================================================
This script scrapes the Y Combinator company directory and saves
structured data for analysis by Claude.

HOW IT WORKS:
- YC's company directory at ycombinator.com/companies uses an Algolia
  search backend. We hit that API directly to get clean JSON data.
- No browser automation needed — it's a simple HTTP request.
- We paginate through ALL companies and save to CSV + JSON.

SETUP (run these in your terminal):
    pip install requests pandas

USAGE:
    python yc_scraper.py

OUTPUT:
    - yc_companies.csv    (spreadsheet-friendly)
    - yc_companies.json   (for feeding into Claude API)
    - scrape_log.txt      (run metadata)
"""

import requests
import pandas as pd
import json
import time
import os
from datetime import datetime


# ─── Configuration ────────────────────────────────────────────────────────────

OUTPUT_DIR = "./yc_data"
ALGOLIA_APP_ID = "45BWZJ1SGC"  # YC's public Algolia app ID
ALGOLIA_API_KEY = "MjBjYjRiMzY0NzdhZWY0NjExY2NhZjYxMGIxYjc2MTAwNWFkNTkwNTc4NjgxYjU0YzFhYTY2ZGQ5OGY5NDMzZnJlc3RyaWN0SW5kaWNlcz0lNUIlMjJZQ0NvbXBhbnlfcHJvZHVjdGlvbiUyMiUyQyUyMllDQ29tcGFueV9CeV9MYXVuY2hfRGF0ZV9wcm9kdWN0aW9uJTIyJTVEJnRhZz1ZQ19Ub3AlMjBDb21wYW5pZXNfZGlyZWN0b3J5"
ALGOLIA_INDEX = "YCCompany_production"
HITS_PER_PAGE = 1000
MAX_PAGES = 20  # Safety limit — YC has ~5000 companies

# Fields we want to extract from each company
FIELDS_TO_EXTRACT = [
    "name",
    "slug",
    "website",
    "all_locations",
    "long_description",
    "one_liner",
    "team_size",
    "industry",
    "subindustry",
    "launched_at",
    "tags",
    "status",
    "batch",
    "highlight_black",
    "highlight_latinx",
    "highlight_women",
    "top_company",
    "isHiring",
    "nonprofit",
    "demo_day_video_public",
    "app_video_public",
    "industries",
    "regions",
    "stage",
    "url",
]


# ─── Scraper ──────────────────────────────────────────────────────────────────

def fetch_yc_companies():
    """
    Fetches all YC companies from the Algolia search API.
    This is the same API the YC website uses when you browse
    ycombinator.com/companies.
    """
    all_companies = []
    page = 0

    print("=" * 60)
    print("  YC STARTUP INTELLIGENCE — Data Scraper")
    print("=" * 60)
    print()

    while page < MAX_PAGES:
        print(f"  Fetching page {page + 1}...", end=" ")

        url = f"https://{ALGOLIA_APP_ID}-dsn.algolia.net/1/indexes/{ALGOLIA_INDEX}/query"

        headers = {
            "X-Algolia-Application-Id": ALGOLIA_APP_ID,
            "X-Algolia-API-Key": ALGOLIA_API_KEY,
            "Content-Type": "application/json",
        }

        payload = {
            "hitsPerPage": HITS_PER_PAGE,
            "page": page,
            "query": "",  # Empty = all companies
        }

        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            data = response.json()
        except requests.exceptions.RequestException as e:
            print(f"\n  ⚠ Request failed: {e}")
            print("  Trying alternative method...")
            break

        hits = data.get("hits", [])
        total_hits = data.get("nbHits", 0)
        total_pages = data.get("nbPages", 0)

        if not hits:
            print("no more results.")
            break

        all_companies.extend(hits)
        print(f"got {len(hits)} companies (total so far: {len(all_companies)}/{total_hits})")

        if page >= total_pages - 1:
            print(f"\n  ✓ Reached last page ({total_pages} total)")
            break

        page += 1
        time.sleep(0.5)  # Be respectful — don't hammer the API

    return all_companies


def extract_fields(companies):
    """
    Extracts and cleans relevant fields from raw Algolia response.
    """
    cleaned = []

    for company in companies:
        record = {}
        for field in FIELDS_TO_EXTRACT:
            value = company.get(field, None)

            # Flatten lists to comma-separated strings
            if isinstance(value, list):
                if len(value) > 0 and isinstance(value[0], dict):
                    # Handle nested dicts (like industries)
                    value = ", ".join([v.get("name", str(v)) for v in value])
                else:
                    value = ", ".join([str(v) for v in value])

            record[field] = value

        # Add computed fields
        record["yc_url"] = f"https://www.ycombinator.com/companies/{company.get('slug', '')}"
        record["scraped_at"] = datetime.now().isoformat()

        cleaned.append(record)

    return cleaned


def save_data(companies, output_dir):
    """
    Saves scraped data as CSV and JSON.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Save CSV
    df = pd.DataFrame(companies)
    csv_path = os.path.join(output_dir, "yc_companies.csv")
    df.to_csv(csv_path, index=False, encoding="utf-8")
    print(f"  ✓ Saved CSV:  {csv_path} ({len(df)} rows)")

    # Save JSON (for Claude API consumption)
    json_path = os.path.join(output_dir, "yc_companies.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(companies, f, indent=2, ensure_ascii=False)
    print(f"  ✓ Saved JSON: {json_path}")

    # Save scrape log
    log_path = os.path.join(output_dir, "scrape_log.txt")
    with open(log_path, "w") as f:
        f.write(f"YC Scrape Log\n")
        f.write(f"{'=' * 40}\n")
        f.write(f"Timestamp: {datetime.now().isoformat()}\n")
        f.write(f"Total companies: {len(companies)}\n")
        f.write(f"Fields extracted: {', '.join(FIELDS_TO_EXTRACT)}\n\n")

        # Quick stats
        if companies:
            batches = set(c.get("batch", "Unknown") for c in companies if c.get("batch"))
            industries = set(c.get("industry", "Unknown") for c in companies if c.get("industry"))
            active = sum(1 for c in companies if c.get("status") == "Active")
            f.write(f"Unique batches: {len(batches)}\n")
            f.write(f"Unique industries: {len(industries)}\n")
            f.write(f"Active companies: {active}\n")
    print(f"  ✓ Saved log:  {log_path}")

    return df


def print_summary(df):
    """
    Prints a quick summary of the scraped data.
    """
    print()
    print("─" * 60)
    print("  SCRAPE SUMMARY")
    print("─" * 60)
    print(f"  Total companies scraped: {len(df)}")

    if "batch" in df.columns:
        print(f"  Unique batches: {df['batch'].nunique()}")
        recent = df[df['batch'].notna()].sort_values('batch', ascending=False)['batch'].unique()[:5]
        print(f"  Most recent batches: {', '.join(recent)}")

    if "industry" in df.columns:
        print(f"\n  Top industries:")
        for industry, count in df['industry'].value_counts().head(10).items():
            print(f"    {industry}: {count} companies")

    if "status" in df.columns:
        print(f"\n  Company status:")
        for status, count in df['status'].value_counts().items():
            print(f"    {status}: {count}")

    if "team_size" in df.columns:
        sizes = pd.to_numeric(df['team_size'], errors='coerce').dropna()
        if len(sizes) > 0:
            print(f"\n  Team sizes:")
            print(f"    Median: {sizes.median():.0f}")
            print(f"    Mean: {sizes.mean():.0f}")
            print(f"    Max: {sizes.max():.0f}")

    print()
    print("=" * 60)
    print("  ✓ DONE — Data ready for Claude analysis!")
    print(f"  Next: Run  python yc_analyzer.py  to get AI insights")
    print("=" * 60)


# ─── Alternative scraper (if Algolia keys change) ────────────────────────────

def fetch_yc_alternative():
    """
    Fallback: scrapes the YC directory via their public web endpoint.
    Use this if the Algolia API keys have been rotated.
    """
    print("  Using alternative scraping method...")
    all_companies = []
    page = 0

    while True:
        url = "https://www.ycombinator.com/companies"
        params = {"page": page + 1}

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()

            # YC embeds data as JSON in a script tag
            import re
            match = re.search(
                r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>',
                response.text
            )
            if match:
                page_data = json.loads(match.group(1))
                # Navigate the Next.js data structure
                props = page_data.get("props", {}).get("pageProps", {})
                companies = props.get("companies", [])

                if not companies:
                    break

                all_companies.extend(companies)
                print(f"  Page {page + 1}: {len(companies)} companies")
            else:
                print("  Could not find data in page HTML")
                break

        except Exception as e:
            print(f"  Error: {e}")
            break

        page += 1
        time.sleep(1)

    return all_companies


# ─── Main ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Step 1: Fetch all companies
    raw_companies = fetch_yc_companies()

    if not raw_companies:
        print("\n  Algolia method failed. Trying alternative...")
        raw_companies = fetch_yc_alternative()

    if not raw_companies:
        print("\n  ⚠ Could not fetch data. YC may have changed their API.")
        print("  Try inspecting network requests at ycombinator.com/companies")
        print("  and update the ALGOLIA_APP_ID and ALGOLIA_API_KEY above.")
        exit(1)

    # Step 2: Clean and extract fields
    print(f"\n  Processing {len(raw_companies)} companies...")
    cleaned = extract_fields(raw_companies)

    # Step 3: Save
    print()
    df = save_data(cleaned, OUTPUT_DIR)

    # Step 4: Print summary
    print_summary(df)
